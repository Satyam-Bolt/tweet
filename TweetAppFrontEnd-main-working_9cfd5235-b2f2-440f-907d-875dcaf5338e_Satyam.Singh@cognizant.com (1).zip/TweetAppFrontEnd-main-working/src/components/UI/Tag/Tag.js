const Tag = (props) => {
  return <span className="text-primary">{props.children}</span>;
};

export default Tag;
